package com.global.shopping.base;

import java.util.HashSet;
import java.util.Set;

import com.global.shopping.entity.Role;

import jakarta.persistence.Column;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.OneToOne;

@MappedSuperclass
public abstract class BaseUser<ID> {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name="id")
		private ID id;
		private String name;
		private String phoneNumber;
		private String country;
		private String city;
		private String email;
		private String userName;
		private String password;
		
		@OneToOne
		@JoinColumn(name="role_id")
		private Role role;
		
		public BaseUser() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
		public BaseUser(ID id, String name, String phoneNumber, String country, String city, String email,
				String userName, String password, Role role) {
			super();
			this.id = id;
			this.name = name;
			this.phoneNumber = phoneNumber;
			this.country = country;
			this.city = city;
			this.email = email;
			this.userName = userName;
			this.password = password;
			this.role = role;
		}


		public ID getId() {
			return id;
		}

		public void setId(ID id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		public String getPhoneNumber() {
			return phoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}


		public Role getRole() {
			return role;
		}


		public void setRole(Role role) {
			this.role = role;
		}
		
		
		
		
		
	}
	

