package com.global.shopping.entity;

import java.util.Set;
import com.global.shopping.base.BaseUser;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name="customer")
public class Customer extends BaseUser<Long>{

	public Customer() {
		super();
	}

	public Customer(Long id, String name, String phoneNumber, String country, String city, String email, String userName,
			String password,Role role ) {
		super(id, name, phoneNumber, country, city, email, userName, password, role);
		// TODO Auto-generated constructor stub
	}

	
}
