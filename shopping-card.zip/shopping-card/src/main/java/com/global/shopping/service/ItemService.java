package com.global.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.global.shopping.entity.Item;
import com.global.shopping.repository.ItemRepository;

@Service
public class ItemService {
	
	@Autowired
	private ItemRepository itemRepository;
	
	public Item searchItemByName(String name) {
		
		return itemRepository.searchItemByName(name);
	}
	
	public List<Item> showAll() {
		return itemRepository.findAll();
		
	}
	public Item addItem(Item item) {
		return itemRepository.save(item);
	}
	
	public  Item updateItem(Item item) {
		
		return itemRepository.save(item);
	}

}
