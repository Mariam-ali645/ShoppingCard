package com.global.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.global.shopping.entity.Customer;
import com.global.shopping.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public List<Customer> findAll(){
		
		return customerRepository.findAll();
	}
   public Customer insert(Customer customer){
		
		return customerRepository.save(customer);
	}
	
	
	

}
