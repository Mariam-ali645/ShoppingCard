package com.global.shopping.entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Shopping {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private LocalDate orderDate;
	private LocalTime orderTime;
	
	@OneToOne()
	@JoinColumn(name ="customer_id")
	private Customer customer;
	
	
	@OneToMany
	@JoinColumn(name ="Item_id")
	private List<Item> items=new ArrayList<>();


	
	public Shopping() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Shopping(Long id, LocalDate orderDate, LocalTime orderTime, Customer customer, List<Item> items) {
		super();
		this.id = id;
		this.orderDate = orderDate;
		this.orderTime = orderTime;
		this.customer = customer;
		this.items = items;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public LocalDate getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}


	public LocalTime getOrderTime() {
		return orderTime;
	}


	public void setOrderTime(LocalTime orderTime) {
		this.orderTime = orderTime;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public List<Item> getItems() {
		return items;
	}


	public void setItems(List<Item> items) {
		this.items = items;
	}
	
	
	

}
