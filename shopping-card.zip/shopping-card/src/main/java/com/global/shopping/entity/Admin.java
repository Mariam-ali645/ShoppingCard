package com.global.shopping.entity;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.annotations.ManyToAny;

import com.global.shopping.base.BaseUser;

import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="admin")
public class Admin extends BaseUser<Long>{

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admin(Long id, String name, String phoneNumber, String country, String city, String email, String userName,
			String password,Role role ) {
		super(id, name, phoneNumber, country, city, email, userName, password, role);
		// TODO Auto-generated constructor stub
	}

	


}
