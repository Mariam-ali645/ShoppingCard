package com.global.shopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.global.shopping.entity.Role;
import com.global.shopping.repository.RoleRepository;

@Service
public class RoleService {
	
	@Autowired
	private RoleRepository roleRepository;
	
	public Role findByName(String name) {
		return roleRepository.findByName(name);
	}
	
	public List<Role> findAll() {
		
		return roleRepository.findAll();
	}
	
	public Role findById(Long id) {
		
		return roleRepository.findById(id).get();
	}
	public Role insert(Role role) {
		return roleRepository.save(role);
	}

}
