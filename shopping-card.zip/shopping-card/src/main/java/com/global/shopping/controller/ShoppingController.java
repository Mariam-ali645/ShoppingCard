package com.global.shopping.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.global.shopping.entity.Item;
import com.global.shopping.entity.Shopping;
import com.global.shopping.service.ShoppingService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/shopping")
public class ShoppingController {
	
	@Autowired
	private  ShoppingService shoppingService;
	
	@PostMapping
	public  ResponseEntity<Shopping> insert (@RequestBody  Shopping entity) {
		return  ResponseEntity.ok(shoppingService.insert(entity)) ;
		
	}
	
	@DeleteMapping("/{id}")
	public void delete( @PathVariable Long id) {
		shoppingService.remove(id);
		
	}
	@GetMapping("/all")
	public  ResponseEntity<?>  viewItem(){
	     return	ResponseEntity.ok(shoppingService.findAll()) ;
	}

}
