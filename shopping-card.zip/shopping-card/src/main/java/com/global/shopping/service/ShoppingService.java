package com.global.shopping.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.global.shopping.entity.Item;
import com.global.shopping.entity.Shopping;
import com.global.shopping.repository.ShoppingRepository;

@Service
public class ShoppingService {
	
	@Autowired
	private ShoppingRepository shoppingRepository;
	
	//private Set<Item> cart = new HashSet();
	
	public List<Shopping> findAll() {
		return shoppingRepository.findAll();	
	}
	
	public void remove(Long id) {
		
		shoppingRepository.deleteById(id);
		
	}
     public Shopping update(Shopping entity) {
		
		return shoppingRepository.save(entity);
		
	}
     public Shopping insert(Shopping entity) {
 		
 		return shoppingRepository.save(entity);
 		
 	}
	
	
	
//	public void viewItem() {
//		 Iterator<Item> iterator = cart.iterator();
//		 while(iterator.hasNext()) {
//			 Item items=iterator.next();
//			 System.out.println("Item : "+items.getName());
//			 double totalInvoice=0;
//			 totalInvoice += items.getPrice();
//			 System.out.println("Total Invoice = "+totalInvoice);
//			 
//			 
//		 }
//		 if(! iterator.hasNext()) {
//			 System.out.println("the cart is Empty");
//		 }		
//	}
}
	
	
	
	


