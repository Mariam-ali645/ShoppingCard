package com.global.shopping.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.global.shopping.entity.Item;
import com.global.shopping.entity.Shopping;


@Repository
public interface ShoppingRepository extends JpaRepository<Shopping, Long> {

}
