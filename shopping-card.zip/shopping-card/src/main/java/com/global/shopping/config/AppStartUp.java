package com.global.shopping.config;

import java.time.LocalDate;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import com.global.shopping.entity.Admin;
import com.global.shopping.entity.Customer;
import com.global.shopping.entity.Item;
import com.global.shopping.entity.Role;
import com.global.shopping.entity.Shopping;
import com.global.shopping.service.AdminService;
import com.global.shopping.service.CustomerService;
import com.global.shopping.service.ItemService;
import com.global.shopping.service.RoleService;

import com.global.shopping.service.ShoppingService;

@Component
public class AppStartUp implements CommandLineRunner {

	@Autowired
	private ItemService itemService;
	@Autowired
	private RoleService roleService;
	@Autowired
	private AdminService adminService; 
	
	@Autowired
	private ShoppingService shoppingService;
	@Autowired
	private CustomerService customerService;
	
	
	@Override
	public void run(String... args) throws Exception {
		
		if(roleService.findAll().isEmpty()) {
			roleService.insert(new Role(1L,"admin"));
			roleService.insert(new Role(2L,"customer"));
			
		}
		
		if(adminService.findAll().isEmpty()) {
			
			Role adminRole=roleService.findByName("admin");
					
			adminService.insert(new Admin(1L,"ahmed","0101254","eygpt","cairo","ahmed@gmail.com","admin","adminpass", adminRole));
		}
			
		if(customerService.findAll().isEmpty()) {
		
			Role customerRole=roleService.findByName("customer");
			
			customerService.insert(new Customer(1L,"omar","0101054","eygpt","alx","omar@gmail.com","customer","customerpass", customerRole));
				
		}
		
		if(shoppingService.findAll().isEmpty()) {
			
			List<Item> booksItem=new ArrayList<>();
			booksItem.add(itemService.addItem(new Item(1L,"books",200.0,5)));
			
			List<Item> bagsItem=new ArrayList<>();
			bagsItem.add(itemService.addItem(new Item(2L,"bags",300.0,10)));
			
			List<Item> pensItem=new ArrayList<>();
			pensItem.add(itemService.addItem(new Item(3L,"Pens",100.0,5)));
			
			shoppingService.insert(new Shopping(1L,LocalDate.now(),LocalTime.now(), null, booksItem));
			shoppingService.insert(new Shopping(2L,LocalDate.now(),LocalTime.now(), null, bagsItem));
			shoppingService.insert(new Shopping(3L,LocalDate.now(),LocalTime.now(), null, pensItem));
		}

}
}

