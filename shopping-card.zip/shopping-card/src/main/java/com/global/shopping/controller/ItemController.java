
package com.global.shopping.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.global.shopping.entity.Item;
import com.global.shopping.service.ItemService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/item")
public class ItemController {
	
	@Autowired
	private ItemService itemService;
	
	@GetMapping("/{name}")
      public  ResponseEntity<Item>  itemSearch(@PathVariable String name ) {
		
		  return ResponseEntity.ok(itemService.searchItemByName(name)) ;
	   }
	
	@GetMapping("")
	  public ResponseEntity<List<Item>>  showAll() {
		   return  ResponseEntity.ok(itemService.showAll());
		}
	
	 @PostMapping
	   public ResponseEntity<Item> insert(@RequestBody Item item) {
		    return ResponseEntity.ok( itemService.addItem(item));
	}
	
	 @PutMapping
	public  ResponseEntity<Item> update(@RequestBody Item item) {
		
		return ResponseEntity.ok( itemService.updateItem(item));
	}
	
	

}
